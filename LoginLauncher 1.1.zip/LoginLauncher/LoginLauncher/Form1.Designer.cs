﻿
namespace KulecnikGUI
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.možnostiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rychlostPohybuKuličekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pomaluToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rychleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.barvyKuličekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.červenáToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zelenáToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modráToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.barvyPozadíToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nápovědaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backToLauncherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.možnostiToolStripMenuItem,
            this.backToLauncherToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(403, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // možnostiToolStripMenuItem
            // 
            this.možnostiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rychlostPohybuKuličekToolStripMenuItem,
            this.barvyKuličekToolStripMenuItem,
            this.barvyPozadíToolStripMenuItem,
            this.nápovědaToolStripMenuItem});
            this.možnostiToolStripMenuItem.Name = "možnostiToolStripMenuItem";
            this.možnostiToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.možnostiToolStripMenuItem.Text = "Možnosti";
            // 
            // rychlostPohybuKuličekToolStripMenuItem
            // 
            this.rychlostPohybuKuličekToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pomaluToolStripMenuItem,
            this.rychleToolStripMenuItem});
            this.rychlostPohybuKuličekToolStripMenuItem.Name = "rychlostPohybuKuličekToolStripMenuItem";
            this.rychlostPohybuKuličekToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.rychlostPohybuKuličekToolStripMenuItem.Text = "Rychlost pohybu kuliček";
            // 
            // pomaluToolStripMenuItem
            // 
            this.pomaluToolStripMenuItem.Name = "pomaluToolStripMenuItem";
            this.pomaluToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.pomaluToolStripMenuItem.Text = "Pomalu";
            this.pomaluToolStripMenuItem.Click += new System.EventHandler(this.pomaluToolStripMenuItem_Click);
            // 
            // rychleToolStripMenuItem
            // 
            this.rychleToolStripMenuItem.Name = "rychleToolStripMenuItem";
            this.rychleToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.rychleToolStripMenuItem.Text = "Rychle";
            this.rychleToolStripMenuItem.Click += new System.EventHandler(this.rychleToolStripMenuItem_Click);
            // 
            // barvyKuličekToolStripMenuItem
            // 
            this.barvyKuličekToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.červenáToolStripMenuItem,
            this.zelenáToolStripMenuItem,
            this.modráToolStripMenuItem});
            this.barvyKuličekToolStripMenuItem.Name = "barvyKuličekToolStripMenuItem";
            this.barvyKuličekToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.barvyKuličekToolStripMenuItem.Text = "Barvy kuliček";
            // 
            // červenáToolStripMenuItem
            // 
            this.červenáToolStripMenuItem.Name = "červenáToolStripMenuItem";
            this.červenáToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.červenáToolStripMenuItem.Text = "Červená";
            this.červenáToolStripMenuItem.Click += new System.EventHandler(this.červenáToolStripMenuItem_Click);
            // 
            // zelenáToolStripMenuItem
            // 
            this.zelenáToolStripMenuItem.Name = "zelenáToolStripMenuItem";
            this.zelenáToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.zelenáToolStripMenuItem.Text = "Zelená";
            this.zelenáToolStripMenuItem.Click += new System.EventHandler(this.zelenáToolStripMenuItem_Click);
            // 
            // modráToolStripMenuItem
            // 
            this.modráToolStripMenuItem.Name = "modráToolStripMenuItem";
            this.modráToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.modráToolStripMenuItem.Text = "Modrá";
            this.modráToolStripMenuItem.Click += new System.EventHandler(this.modráToolStripMenuItem_Click);
            // 
            // barvyPozadíToolStripMenuItem
            // 
            this.barvyPozadíToolStripMenuItem.Name = "barvyPozadíToolStripMenuItem";
            this.barvyPozadíToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.barvyPozadíToolStripMenuItem.Text = "Barvy pozadí";
            this.barvyPozadíToolStripMenuItem.Click += new System.EventHandler(this.barvyPozadíToolStripMenuItem_Click);
            // 
            // nápovědaToolStripMenuItem
            // 
            this.nápovědaToolStripMenuItem.Name = "nápovědaToolStripMenuItem";
            this.nápovědaToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.nápovědaToolStripMenuItem.Text = "Nápověda";
            this.nápovědaToolStripMenuItem.Click += new System.EventHandler(this.nápovědaToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(400, 400);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // backToLauncherToolStripMenuItem
            // 
            this.backToLauncherToolStripMenuItem.Name = "backToLauncherToolStripMenuItem";
            this.backToLauncherToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.backToLauncherToolStripMenuItem.Text = "Back to Launcher";
            this.backToLauncherToolStripMenuItem.Click += new System.EventHandler(this.backToLauncherToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 429);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem možnostiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rychlostPohybuKuličekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pomaluToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rychleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem barvyKuličekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem červenáToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zelenáToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modráToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem barvyPozadíToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nápovědaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backToLauncherToolStripMenuItem;
    }
}

