﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace KulecnikGUI
{
    public partial class Form1 : Form
    {
        public int pictureBoxWidth = 400;
        public int pictureBoxHeight = 400;
        public int zmenaBarvy;
        List<Kulicka> kulicky = new List<Kulicka>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            VykresliKulicky();
            timer1.Start();
            timer1.Interval = 20;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            foreach (Kulicka k in kulicky)
            {
                k.Vykresli(e.Graphics, zmenaBarvy);
            }
            foreach (Kulicka k in kulicky)
            {
                k.PosunSouradnice();
            }
        }
        public void VykresliKulicky()
        {
            Random rnd = new Random();

            for (int i = 0; i < 69; i++)
            {
                kulicky.Add(new Kulicka(rnd.Next(0, pictureBoxWidth),rnd.Next(0, pictureBoxHeight),rnd.Next(-1, 2),rnd.Next(-1, 2),Convert.ToByte(rnd.Next(0, 255)),Convert.ToByte(rnd.Next(0, 255)),Convert.ToByte(rnd.Next(0, 255))));                   
            }
        }

        private void pomaluToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timer1.Interval = 100;
        }

        private void rychleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timer1.Interval = 1;
        }

        private void červenáToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zmenaBarvy = 1;
        }

        private void zelenáToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zmenaBarvy = 2;
        }

        private void modráToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zmenaBarvy = 3;
        }

        private void barvyPozadíToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                pictureBox1.BackColor = dlg.Color;
            }
        }

        private void nápovědaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Napoveda form = new Napoveda();
            form.Show();
        }

        private void backToLauncherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            new LoginLauncher.MainScreen().Show();
        }
    }
}
