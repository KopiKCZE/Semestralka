﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace KulecnikGUI
{
	class Kulicka
	{
		private int Width = 400;
		private int Height = 400;

		public int x;
		public int y;

		public int vektorX;
		public int vektorY;

		public byte barva1;
		public byte barva2;
		public byte barva3;

		public void PosunSouradnice()
		{
			if (x == 0 || x == Width - 1)
			{
				vektorX = -vektorX;
				ZmenBarvu();
			}
			if (y == 0 || y == Height - 1)
			{
				vektorY = -vektorY;
				ZmenBarvu();
			}
			x = x + vektorX;
			y = y + vektorY;
		}
		public void ZmenBarvu()
		{
			Random rnd = new Random();
			barva1 = Convert.ToByte(rnd.Next(0, 255));
			barva2 = Convert.ToByte(rnd.Next(0, 255));
			barva3 = Convert.ToByte(rnd.Next(0, 255));
		}
		public void Vykresli(Graphics g, int zmenaBarvy)
		{
			if (x < 0 || x >= Width || y < 0 || y >= Height)
			{
				return;
			}

			Color color = Color.FromArgb(255, barva1, barva2, barva3);
			switch (zmenaBarvy)
			{
				case 1:
					color = Color.FromArgb(255, barva1, 0, 0);
					break;
				case 2:
					color = Color.FromArgb(255, 0, barva1, 0);
					break;
				case 3:
					color = Color.FromArgb(255, 0, 0, barva1);
					break;
				case 4:
					color = Color.FromArgb(255, barva1, barva2, barva3);
					break;
			}
			Brush b = new SolidBrush(color);
			g.FillEllipse(b, x, y, 20, 20);
		}
		public Kulicka(int x, int y, int vektorX, int vektorY, byte barva1, byte barva2, byte barva3)
		{
			this.x = x;
			this.y = y;
			this.vektorX = vektorX;
			this.vektorY = vektorY;
			this.barva1 = barva1;
			this.barva2 = barva2;
			this.barva3 = barva3;
		}
	}
}
